public class Pas extends KucniLjubimac{

    @Override
    public void glasaSe() {
        System.out.println("Vau Vau!");
    }

    public void nosiLopticu(){}

    public Pas(int godRodjenja) {
        super(godRodjenja);
    }

}
