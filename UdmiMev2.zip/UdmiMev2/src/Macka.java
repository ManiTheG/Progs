public class Macka extends KucniLjubimac{

    @Override
    public void glasaSe() {
        System.out.println("Mijau Mijau!");
    }

    public void loviMisa(){}

    public Macka(int godRodjenja) {
        super(godRodjenja);
    }


}
