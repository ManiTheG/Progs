public class Main {
    public static void main(String[] args) {

        Utocist utociste = new Utocist();

        utociste.udomljavaj();


    }

}
